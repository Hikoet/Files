<html>
<head>
<title>JudgeOnline Administration</title>
</head>
<frameset rows="20,*">
<frame name="rank" src="../contest.php">
<frame name="status" src="../status.php">
<noframes>

</noframes>
</frameset>
</html>
