ace.define("ace/snippets/kotlin",[], function(require, exports, module) {
"use strict";

exports.snippetText =undefined;
exports.scope = "";

});
                (function() {
                    ace.require(["ace/snippets/kotlin"], function(m) {
                        if (typeof module == "object" && typeof exports == "object" && module) {
                            module.exports = m;
                        }
                    });
                })();
            